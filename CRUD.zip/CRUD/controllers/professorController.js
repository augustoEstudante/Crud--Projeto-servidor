const professorModel = require("../models/professorModel")

class professorController{
    buscar(){
        return professorModel.listar();
        //"consulta realizada com sucesso..."
    }

    criar(novoprofessor){
            return professorModel.criar(novoprofessor);
        }

    alterar(professorAtualizado, id){
            return professorModel.atualizar(professorAtualizado, id);
        }

    apagar(professorExclusao, id){
            return professorModel.deletar(professorExclusao, id);
        }
}

module.exports = new professorController();
