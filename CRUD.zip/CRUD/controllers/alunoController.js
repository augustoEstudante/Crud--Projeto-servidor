const alunoModel = require("../models/alunoModel")

class alunoController{
    buscar(){
        return alunoModel.listar();
        //"consulta realizada com sucesso..."
    }

    criar(novoaluno){
        return alunoModel.criar(novoaluno);
    }

    alterar(alunoAtualizado, id){
        return alunoModel.atualizar(alunoAtualizado, id);
    }

    apagar(id){
        return alunoModel.deletar(id);
    }
}

module.exports = new alunoController();
