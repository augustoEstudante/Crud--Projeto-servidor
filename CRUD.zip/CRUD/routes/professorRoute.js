const professorController = require("../controllers/professorController");
const Router = require("express").Router;
const router = Router();

//crud

router.get("/professores", (req, res) => {
    const respcontroller = professorController.buscar();
    respcontroller.then(professores => res.status(200).json(professores))
        .catch(error => res.status(400).json(error.message));
    //res.send("Clientes consultados com sucesso");
});

router.post("/professor", (req, res) => {
    const novoprofessor = req.body;
    const professor = professorController.criar(novoprofessor);
    professor.then(professorInserido => res.status(201).json(professorInserido))
        .catch(error => res.status(400).json(error.message));
    //res.send("Clientes cadastrado com sucesso");
});

router.put("/professor/:id", (req, res) => {
    const { id } = req.params;
    const professorAtualizado = req.body;
    const professorAtualizar = professorController.alterar(professorAtualizado, id);
    professorAtualizar.then(resulProfessorAtualizado => res.status(200).json(resulProfessorAtualizado))
        .catch(error => res.status(400).json(error.message))
    // res.send("Clientes atualizado com sucesso");
});

router.delete("/professores/:id", (req, res) => {
    const { id } = req.params;
    const professorDeletar = professorController.apagar(id);
    professorDeletar.then(professorDeletado => res.status(200).json(professorDeletado))
    .catch(error => res.status(400).json(error.message));
    //res.send("Clientes deletado com sucesso");
});

module.exports = router 