const alunoController = require("../controllers/alunoController");
const Router = require("express").Router;
const router = Router();

//crud

router.get("/alunos", (req, res) => {
    const respcontroller = alunoController.buscar();
    respcontroller.then(alunos => res.status(200).json(alunos))
        .catch(error => res.status(400).json(error.message));
    //res.send("Clientes consultados com sucesso");
});

router.post("/aluno", (req, res) => {
    const novoaluno = req.body;
    const aluno = alunoController.criar(novoaluno);
    aluno.then(alunoInserido => res.status(201).json(alunoInserido))
        .catch(error => res.status(400).json(error.message));
    //res.send("Clientes cadastrado com sucesso");
});

router.put("/aluno/:id", (req, res) => {
    const { id } = req.params;
    const alunoAtualizado = req.body;
    const alunoAtualizar = alunoController.alterar(alunoAtualizado, id);
    alunoAtualizar.then(resulAtualizado => res.status(200).json(resulAtualizado))
        .catch(error => res.status(400).json(error.message));
    // res.send("Clientes atualizado com sucesso");
});

router.delete("/alunos/:id", (req, res) => {
    const { id } = req.params;
    const alunoDeletar = alunoController.apagar(id);
    alunoDeletar.then(alunoDeletado => res.status(200).json(alunoDeletado))
    .catch(error => res.status(400).json(error.message));
    //res.send("Clientes deletado com sucesso");
});

module.exports = router 