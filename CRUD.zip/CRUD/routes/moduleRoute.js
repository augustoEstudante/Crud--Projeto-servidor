const routerAlunos = require("./alunoRoute.js");
const routerProfessores = require("./professorRoute.js");

module.exports = (app) => {
    app.use(routerAlunos);
    app.use(routerProfessores);
}

