const connection = require("../connection/connection");

class alunoModel {
    listar() {
        const sql = "select * from alunos";
        return new Promise((resolve, reject) => {
            connection.query(sql, {}, (error, resposta) => {
                if (error) {
                    console.log("Ocorreu um erro na consulta");
                    reject(error);
                }
                console.log("Consulta realizada com sucesso..")
                resolve(resposta);
            });
        })
    }

    criar(novoaluno) {
        const sql = "insert into alunos set ?";
        console.log("Dados do aluno a serem inseridos: ", novoaluno);
        return new Promise((resolve, reject) => {
            connection.query(sql, novoaluno, (error, resposta) => {
                if (error) {
                    console.log("Erro ao inserir aluno");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Aluno inserido com sucesso");
                resolve(resposta);
            });
        })
    }

    atualizar(alunoAtualizado, id) {
        const sql = "update alunos set ? where id = ?";
        //console.log("Dados do cliente a serem inseridos: ", novocliente);
        return new Promise((resolve, reject) => {
            connection.query(sql, [alunoAtualizado, id], (error, resposta) => {
                if (error) {
                    console.log("Erro ao atualizar aluno");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Aluno atualizado com sucesso");
                resolve(resposta);
            });
        })
    }

    deletar(alunoExclusao, id) {
        const sql = "delete from alunos where id=?";
        //console.log("Dados do cliente a serem inseridos: ", novocliente);
        return new Promise((resolve, reject) => {
            connection.query(sql, [alunoExclusao, id], (error, resposta) => {
                if (error) {
                    console.log("Erro ao deletar aluno");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Aluno deletado com sucesso");
                resolve(resposta);
            });
        })
    }
}

module.exports = new alunoModel();
