const connection = require("../connection/connection");

class professorModel {
    listar() {
        const sql = "select * from professores";
        return new Promise((resolve, reject) => {
            connection.query(sql, {}, (error, resposta) => {
                if (error) {
                    console.log("Ocorreu um erro na consulta");
                    reject(error);
                }
                console.log("Consulta realizada com sucesso..")
                resolve(resposta);
            });
        })
    }

    criar(novoprofessor) {
        const sql = "insert into professores set ?";
        console.log("Dados do professor a serem inseridos: ", novoprofessor);
        return new Promise((resolve, reject) => {
            connection.query(sql, novoprofessor, (error, resposta) => {
                if (error) {
                    console.log("Erro ao inserir professor");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Professor inserido com sucesso");
                resolve(resposta);
            });
        })
    }

    atualizar(professorAtualizado, id) {
        const sql = "update professores set ? where id=?";
        //console.log("Dados do cliente a serem inseridos: ", novocliente);
        return new Promise((resolve, reject) => {
            connection.query(sql, [professorAtualizado, id], (error, resposta) => {
                if (error) {
                    console.log("Erro ao atualizar professor");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Professor atualizado com sucesso");
                resolve(resposta);
            });
        })
    }

    deletar(professorExclusao, id) {
        const sql = "delete from professores where id=?";
        //console.log("Dados do cliente a serem inseridos: ", novocliente);
        return new Promise((resolve, reject) => {
            connection.query(sql, [professorExclusao, id], (error, resposta) => {
                if (error) {
                    console.log("Erro ao deletar professor");
                    console.log(error.message);
                    reject(error);
                }
                console.log("Professor deletado com sucesso");
                resolve(resposta);
            });
        })
    }
}

module.exports = new professorModel();
