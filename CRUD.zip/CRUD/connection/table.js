class Tables {
    init(connect) {
        this.connect = connect;
        this.createTableAluno();
        this.createTableProfessores();
    }

    createTableAluno() {
        const sql =
        `CREATE TABLE IF NOT exists alunos(
        id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        telefone VARCHAR(15),
        data_de_nascimento DATE
        );
    `;
        this.connect.query(sql, (error) => {
            if (error) {
                console.log("Erro ao criar tabela alunos");
                console.log(error.message);
                return;
            }
            console.log("Tabela alunos criada com sucesso");
        });
    }

    createTableProfessores() {
        const sql =
        `CREATE TABLE IF NOT exists professores(
        id INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        telefone VARCHAR(15),
        materia VARCHAR(100) NOT NULL
        );
    `;
        this.connect.query(sql, (error) => {
            if (error) {
                console.log("Erro ao criar tabela professores");
                console.log(error.message);
                return;
            }
            console.log("Tabela professores criada com sucesso");
        });
    }
}

module.exports = new Tables();